
import streamlit as st
import torch
from pathlib import Path

st.set_page_config(page_title="Ignition Point Detector v1.6.0[인천소방]", layout="centered")
st.markdown("## 🔥 발화점 검출기")

@st.cache_resource
def load_model(model_file):
    import torch.serialization
    torch.serialization.add_safe_globals({'models.yolo.DetectionModel': torch.nn.Module})
    return torch.load(model_file, map_location='cpu', weights_only=False)

uploaded_model = st.file_uploader("YOLOv5 모델 (.pt) 파일 업로드", type=['pt'])
if uploaded_model:
    model = load_model(uploaded_model)
    st.success("모델이 성공적으로 로드되었습니다.")
